package com.chich.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Применяем сохранённую тему до создания экрана
        val prefs = getSharedPreferences("chich_prefs", MODE_PRIVATE)
        if (prefs.getBoolean("dark_theme", false)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Кнопка "Запустить чич" — открывает экран блокировки
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            startActivity(Intent(this, LockActivity::class.java))
        }

        // Шестерёнка — открывает настройки
        findViewById<ImageView>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}
